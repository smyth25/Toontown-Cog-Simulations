#' Cog database
#'
#' Data file containing information about each Toontown Cog. Contains their names, ladder, tier, and moveset. Stored in a long format, such that each row corresponds to a specific move at a specific level.
#'
#' @format Data frame with 620 rows and 9 columns:
#' \describe{
#' \item{Name}{Name of cog}
#' \item{Ladder}{Corporate ladder that cog is on}
#' \item{Tier}{Level tier that cog is on (1 = levels 1-5, 2 = levels 2-6, etc...)}
#' \item{Levels}{Specific level of the subsequent move}
#' \item{Moves}{Name of a move}
#' \item{Damage}{Amount of laff deducted by the move}
#' \item{Accuracy}{Probability that the move hits}
#' \item{Usage}{Probability that this move is selected in combat}
#' \item{Group}{Binary variable that specifies whether it is a group attack or not}
#' }
#'
#' @source {Created by the cog_create function}
#'
#' @examples
#' data(ttcogs)
"ttcogs"

#' Cog simulation example
#'
#' Example data file containing results of a 1000 turn combat simulation for every cog, at every level, ranging from 1-4 toons in combat. Generated using a seed of 100 for the purposes of reproducibility.
#'
#' @format Data frame with 640000 rows and 9 columns:
#' \describe{
#' \item{Name}{Name of cog}
#' \item{Ladder}{Corporate ladder that cog is on}
#' \item{Tier}{Level tier that cog is on (1 = levels 1-5, 2 = levels 2-6, etc...)}
#' \item{Level}{Level of the cog during turn}
#' \item{Move}{Name of the move used}
#' \item{Hit}{Number of toons hit by the move}
#' \item{Damage}{Total laff deducted by the move}
#' \item{Toons}{Number of toons in combat}
#' \item{Group}{Binary variable that specifies whether it was a group attack or not}
#' }
#'
#' @source {Created by the cog_sim function}
#'
#' @examples
#' data(cog_simulation)
"cog_simulation"

#' Cog simulation summary example
#'
#' Example data file containing a summary of the example data file cog_simulation.
#'
#' @format Data frame with 640 rows and 13 columns:
#' \describe{
#' \item{Name}{Name of cog}
#' \item{Ladder}{Corporate ladder that cog is on}
#' \item{Tier}{Level tier that cog is on (1 = levels 1-5, 2 = levels 2-6, etc...)}
#' \item{Level}{Level of the cog during turn}
#' \item{Turns}{Number of turns simulated}
#' \item{Toons}{Number of toons in combat}
#' \item{Hit_ratio}{Proportion of toons hit throughout combat}
#' \item{Single_hit_ratio}{Proportion of successful single-target moves throughout combat}
#' \item{group_hit_ratio}{Proportion of toons hit by group attacks throughout combat}
#' \item{Damage_ratio}{Average laff deducted per turn}
#' \item{Single_damage_ratio}{Average laff deducted per turn by single-target moves}
#' \item{Group_damage_ratio}{Average laff deducted per turn by group-target moves}
#' \item{Group_ratio}{Proportion of turns in which group-target moves were used}
#' }
#'
#' @source {Created by the cog_comsum function}
#'
#' @examples
#' data(cog_summary)
"cog_summary"










