#' @title Cog creator function
#'
#' @description Allows details of a cog to be input into a data frame, including name, ladder, tier, and moveset. Damage, accuracy, and usage values for each move at each level are inputted through command line prompts.
#'
#' @param cogname a string specifying the name of the cog. "Cog" by default.
#' @param ladder a string specifying which corporate ladder the cog belongs to. Blank by default.
#' @param tier an integer representing which ladder tier the cog is on. For example tier 1 means levels 1-5, while tier 5 means levels 5-9. Set to 1 by default.
#' @param move_list a list of strings specifying the name of each move in the cog's moveset. Required input with no default.
#' @param export boolean input that determines whether a .csv file is generated from the data frame. False by default.
#'
#' @return dataframe containing (number of moves * 5) rows and 9 columns.
#'
#' @examples cog_create("Flunky", "Bossbot", 1, c("Pound Key", "Clip on Tie", "Shred")) # Foundation for creating a Flunky
#'
#' @export

cog_create <- function(cogname = "Cog", ladder = "", tier = 1, move_list, export = FALSE) {
  Levels = rep(tier:(tier + 4), each = length(move_list))
  Name = rep(cogname, length(Levels))
  Ladder = rep(ladder, length(Levels))
  Tier = rep(tier, length(Levels))
  Moves = rep(move_list, 5)
  three = cbind(Name, Ladder)
  three = cbind(three, Tier)
  three = cbind(three, Levels)
  three = cbind(three, Moves)
  move_data = data.frame()
  for (i in tier:(tier + 4)) {
    for (j in move_list) {
      damage = as.integer(readline(prompt = paste("Please enter the level", i, "damage value for", j,"")))
      accuracy = as.integer(readline(prompt = paste("Please enter the level", i, "accuracy value for", j,"")))
      usage = as.integer(readline(prompt = paste("Please enter the level", i, "usage value for", j,"")))
      move_data = rbind(move_data, c(damage, accuracy, usage))
    }
  }
  all = cbind(three, move_data)
  all = all[order(all$Moves), ]
  colnames(all)[6] <- "Damage"
  colnames(all)[7] <- "Accuracy"
  colnames(all)[8] <- "Usage"
  group = data.frame()
  for (i in unique(all$Moves)) {
    group_in = as.integer(readline(prompt = paste("Is", i, "a group attack? Type '1' for yes and '0' for no: ")))
    group_in = data.frame("Group" = rep(group_in, 5))
    group = rbind(group, group_in)
  }
  if (export == TRUE) {
    csv <- cbind(all, group)
    write.csv(csv, paste(name, ".csv", sep = ""))
    message("File saved to ", getwd())
  }
  return(cbind(all, group))
}


